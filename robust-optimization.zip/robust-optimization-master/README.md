# robust-optimization
learn from xprog and bertsimas's paper(price of robustness)
the code is based on python and need gurobi or cplex
